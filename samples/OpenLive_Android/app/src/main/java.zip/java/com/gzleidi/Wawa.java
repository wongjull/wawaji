package com.gzleidi;

import android.util.Log;

import java.net.URI;
import java.net.URISyntaxException;

import org.java_websocket.WebSocketImpl;
import org.java_websocket.client.WebSocketClient;
import org.java_websocket.drafts.Draft;
import org.java_websocket.drafts.Draft_6455;
import org.java_websocket.handshake.ServerHandshake;

public class Wawa {
    private WebSocketClient cc;

    public Wawa( ) {
        WebSocketImpl.DEBUG = true;
    }

    public void connect() {
        try {
            // cc = new ChatClient(new URI(uriField.getText()), area, ( Draft ) draft.getSelectedItem() );
            cc = new WebSocketClient( new URI( "ws://api.h5.jamma.cn:88" ) ) {

                @Override
                public void onMessage( String message ) {
                    // ta.append( "got: " + message + "\n" );
                }

                @Override
                public void onOpen( ServerHandshake handshake ) {
                    Log.d( "wawa", "connected" );
                }

                @Override
                public void onClose( int code, String reason, boolean remote ) {
                    // ta.append( "You have been disconnected from: " + getURI() + "; Code: " + code + " " + reason + "\n" );
                }

                @Override
                public void onError( Exception ex ) {
                    // ta.append( "Exception occured ...\n" + ex + "\n" );
                    ex.printStackTrace();
                }
            };
            cc.connect();
        } catch ( URISyntaxException ex ) {
            // ta.append( uriField.getText() + " is not a valid WebSocket URI\n" );
        }
    }

    public void close(){
        cc.close();
    }

}
